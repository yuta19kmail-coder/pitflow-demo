/* ========================================
   sales-count.js  -  「売上をどの月に数えるか」を決める、たった1本の物差し
   ----------------------------------------
   PitFlow v1.61.0（2026-08-06・ゆうた指定）

   ◎ゆうた指定
     「売上サマリー等の集計に、受注済みの確定金額が入っている車両でも、
       返車予定が当月内でなければ、その時までずらす。
       基本的には**返車予定日が月内かどうか**が分けるポイント」

   ◎これまで（不具合）
     売上ビューの「確定（受注済）」「予定」「見込」は、**進行中というだけで無条件に当月**へ積んでいた。
     返車予定が翌月の車まで今月の着地見込みに乗ってしまい、月をまたぐたびに数字が二重に見えた。

   ◎これから（決めごと）
     🔴 **1台につき「数える日」は1つだけ**。その日が入っている月に、その台の金額を積む。

     | 状態 | 数える日 |
     |---|---|
     | 実績（返車済み） | **実績カウント日 `completedAt`**（無ければ確定返車日→返車日） |
     | 実績待・進行中（作業完了・返車待ち・受注済・見積提示済・入庫済） | **返車予定日 `returnDate`** |
     | 予約（未入庫） | **返車予定日**。無ければ **入庫予定日＋概算 預かり日数** |

     - **返車予定日が空（未定）＝当月に寄せる**（決まった時点で自動でその月へ移る）
     - **返車予定日が過ぎている（遅れている）＝当月に寄せる**（締めた過去の月の数字を後から動かさない）
     - **実績だけは日付そのまま**（過去は過去のまま。寄せない）

   ◎使い方
     - `pitSalesCountDate(c)` … その車の金額を数える日（'YYYY-MM-DD'／未定は ''）
     - `pitSalesTier(c)`      … 確度の区分（🔴 v1.167.0 から **6つ**）
         `actual`（実績）/ `actualWait`（実績待）/ `confirmed`（確定）/
         `planned`（予定）/ `prospect`（見込）/ `forecast`（予測）／対象外は null
       ⚠ **並びは確からしい順**。画面はこの順に出す。
     - `pitSalesInRange(c, fromStr, toStr, todayStr)` … その期間に数えるか（true/false）

   🔴 **写しを作らないこと。** 期間で絞る集計は必ずこの3本を通す。
      （sales.js / mydash.js / mech-summary.js / maintdash.js が呼んでいる）

   ◎ v1.99.0（2026-08-15・ゆうた指定）**「売上なしでアーカイブ」した車**
     🔴 **売上0円で返した車は、実績にも売上にも一切乗せない。** ただし**来店した事実は残す**
        （＝お客様の来店履歴には出す。次に来た時に前回なにをしたか分かるように）。
     🔴 **その車かどうかの物差しは `pitCardNoSale(c)` 1本。** 画面ごとに `c.noSale` を直に見ないこと。
        ⚠ 印が付いた車は `pitSalesTier` が **null**／`pitSalesInRange` が **false**／
           `pitSalesCountDate` が **''**（数える日が無い）を返す。＝期間の集計を通る道は全部ふさいである。
     🔴 **実績カウント日（completedAt）は入れない。** 実績カレンダー・月次の実績・ダッシュボードは
        全部この日付で拾っているので、**日付を入れない＝どこにも数えられない**が一番事故が少ない（二重の守り）。

   ⚠ 読み込みは state.js より後ろ、使う側（sales.js / mydash.js …）より前。
   ======================================== */
(function(){
  'use strict';

  /* 🔴 v1.167.0（ゆうた指定 2026-08-21）**「確定」から「実績待」を切り出した。**
     🗣「現状 実績→確定 のながれだが、実際にはここには
        **完了してるけど返車してないだけ**。と**完了してないこれから作業する**。が混ざっちゃってる」
     ＝ 直す前の「確定」は `parts / work / workDone / outsource ＋ 完TEL待ち以降` を**ひとまとめ**にしていた。
        **作業が終わっている車**と**これから作業する車**が同じ数字に入っていて、
        「あといくら確実に入るのか」が読めなかった。
     🔴 これから
        ・**実績待**＝**作業完了エリア（workDone）** または **返車カレンダーにいる（returnStage）**
          ＝ **実績カレンダーに入っていない**（まだ `returned` ではない）
        ・**確定**＝受注済だが**まだ作業が終わっていない**（パーツ待ち・作業待ち・外注）
     ⚠ ここが唯一の見分け。画面ごとに `status==='workDone'` と書かないこと。 */
  var CONFIRMED  = ['parts','work','outsource'];   // 受注済だが、まだ作業が終わっていない
  var DONE_WORK  = ['workDone'];                   // 作業完了エリア

  /* ===== ⓪「売上なしでアーカイブ」した車か =====
     🔴 v1.103.0 **判定そのものは `js/pit-share.js` に移した**（MHS からも借りるため）。
        ここは呼ぶだけ。**条件をここに書き戻さないこと。** */
  function pitCardNoSale(c){ return window.pitCardNoSale ? window.pitCardNoSale(c) : !!(c && c.noSale); }

  function s(v){ return (v == null) ? '' : String(v); }
  function n(v){ v = +v; return isFinite(v) ? v : 0; }
  function pad(x){ return (x < 10 ? '0' : '') + x; }
  function ymdL(d){ return d.getFullYear() + '-' + pad(d.getMonth()+1) + '-' + pad(d.getDate()); }
  function addStr(str, days){
    var p = s(str).split('-'); if (p.length !== 3) return '';
    var d = new Date(+p[0], (+p[1])-1, +p[2]); if (isNaN(d.getTime())) return '';
    d.setDate(d.getDate() + days); return ymdL(d);
  }
  function today(){ var t = new Date(); t.setHours(0,0,0,0); return ymdL(t); }

  /* 概算の預かり日数（カードの指定 → 作業タイプ別の目安 → 5日） */
  function holdOf(c){
    if (c && c.estHoldDays != null && c.estHoldDays !== '') return Math.max(0, n(c.estHoldDays));
    if (window.pitEstHold){
      try { return Math.max(0, n(pitEstHold(c.workType, c.dropType, window.pitTeamKey ? pitTeamKey(c) : 'default'))); } catch(e){}
    }
    return 5;
  }

  /* 🆕 v1.156.0（ゆうた指定）**案内用の「暫定預かり日数」。まだ決まっていなければ null。**
     ⚠ 上の holdOf は最後に必ず 5 を返す（売上の見込みには日付が要るため）。
     　 最短入庫日の案内は「**作業タイプを選んだか／まだか**」で決まりが変わるので、
     　 決まっていない時は **null** と答えるこちらを使う。
     🔴 元になる表は settings の estHold（作業タイプ別の目安）1本。ここで日数を決め打ちしない。 */
  /* 🔴🔴 v1.158.0（ゆうた確定）**0 を null に潰さないこと。**
     🗣「**0日あり得る。いって帰ってくるだけで代車使いたいと。代車的には1日利用として存在する**」
     ＝ `0`（当日返し）は**決まっている答え**。`null`（まだ決まっていない）とは別物。
     ⚠ v1.157.1 までは 0 を null にしていたので、当日返しのお客様に
        **「1週間まるごと空いている日」からしか案内できていなかった**（loaner-free.js の planNeed 参照）。 */
  function planHoldOf(c){
    if (!c) return null;
    if (c.estHoldDays != null && c.estHoldDays !== ''){
      return Math.max(0, n(c.estHoldDays));      /* 0＝当日返し。そのまま返す */
    }
    var wt = c.workType || ((Array.isArray(c.workTypes) && c.workTypes.length) ? c.workTypes[0] : '');
    if (!wt) return null;                 /* 作業タイプ未選択＝まだ決まっていない */
    if (window.pitEstHold){
      try {
        return Math.max(0, n(pitEstHold(wt, c.dropType, window.pitTeamKey ? pitTeamKey(c) : 'default')));
      } catch (e) {}                      /* 待ち・当日仕上げは 0＝代車を使うなら1日ぶん */
    }
    return null;
  }

  /* ===== ①その車の金額を「いつ」数えるか =====
     🔴 v1.65.0（ゆうた確定）返車日は**3段のチェーン**になった（return-slot.js）。
        まだ返していない車は **C（確定返車日）→ B（受注時の約束）→ A（概算＝入庫日＋預かり日数）** の順に見る。
        ゆうた指定「予定で月内に入るか入らないかは B を見る」＋ 完TEL済なら C のほうが確かなので C を先に。
     ⚠ ここで日付を組み立てないこと。**物差しは return-slot.js の 1本**。 */
  function pitSalesCountDate(c){
    if (!c) return '';
    if (pitCardNoSale(c)) return '';        /* 🔴 v1.99.0 売上なし＝数える日そのものが無い */
    /* 実績＝実績カウント日が正。返車日は予備（v1.57.0 で completedAt が売上の基準になった）
       🛡🛡 v2.9.0（ゆうた指定 2026-08-25）**保険は「入金日」で数える。**
       　　 「保険が付いたものは返車と入金が大きくずれる。作業→返車→請求書作成→売上。
       　　　 自社の計算方法だと一番最後の売上日を実質的な返車日として計上している」
       🔴 だから保険は **`completedAt` にも `returnDate` にも落とさない。** 入金日だけを見る。
          ⚠ ここを下の `||` の連鎖に戻すと、**入金前の保険車が返車日で計上されてしまう**
             （＝今回いちばん防ぎたい事故）。物差しは `insurance-pit.js` の1本。 */
    if (c.status === 'returned') {
      if (window.pitInsResultDate && window.pitCardInsurance && pitCardInsurance(c)) {
        return s(pitInsResultDate(c));        /* 入金前は '' ＝どの月にも数えない */
      }
      return s(c.completedAt) || s(c.returnDateFinal) || s(c.returnDate);
    }
    if (window.pitReturnDates){
      var d = pitReturnDates(c);
      return s(d.c) || s(d.b) || s(d.a);
    }
    /* 部品が無い時の保険（読み込み順が崩れた場合） */
    if (s(c.returnDatePlan)) return s(c.returnDatePlan);
    if (s(c.returnDate)) return s(c.returnDate);
    if (s(c.reserveDate)) return addStr(s(c.reserveDate), holdOf(c));
    return '';   /* ＝未定 */
  }

  /* ===== ②確度の区分（状態だけで決まる。期間は見ない） ===== */
  function pitSalesTier(c){
    if (!c || c.status === 'scrap') return null;
    if (pitCardNoSale(c)) return null;      /* 🔴 v1.99.0 売上なし＝どの区分にも入れない */
    var st = c.status;
    /* 🛡 v2.9.0 保険で入金待ち＝返したが、まだ実績カレンダーに入っていない。
       ＝ 状態としては「実績待」（作業は終わっている。あとはお金が入るだけ）。
       ⚠ 数える日が無いので、どの月にも積まれない（`pitSalesInRange` が false）。それで正しい。 */
    if (st === 'returned' && window.pitInsPayWait && pitInsPayWait(c)) return 'actualWait';
    if (st === 'returned') return 'actual';                                            /* 実績＝返車済み（実績カレンダーに入った） */
    if (st === 'reserved') return 'forecast';                                          /* 予測＝未入庫の予約 */
    /* 🔴 v1.167.0 実績待＝**作業は終わっている。あとは返すだけ。**
       作業完了エリアにいる or 返車カレンダーにいる（完TEL待ち以降）＝実績カレンダーにはまだ入っていない。 */
    if (DONE_WORK.indexOf(st) >= 0 || c.returnStage) return 'actualWait';
    if (CONFIRMED.indexOf(st) >= 0) return 'confirmed';                                /* 確定＝受注済・これから作業する */
    if (st === 'contact') return 'planned';                                            /* 予定＝連絡中（見積提示済） */
    if (st === 'check' || st === 'estim') return 'prospect';                            /* 見込＝入庫済・受注前 */
    return null;
  }

  /* ===== ③その期間（月・クォーター）に数えるか ===== */
  function pitSalesInRange(c, fromStr, toStr, todayStr){
    if (!c) return false;
    if (pitCardNoSale(c)) return false;     /* 🔴 v1.99.0 売上なし＝どの期間にも数えない */
    todayStr = todayStr || today();
    var d = pitSalesCountDate(c);

    /* 実績＝日付そのまま。過去も未来も寄せない
       ⚠ 🛡 v2.9.0 保険で入金待ちは d が '' ＝ここで false になる。
          **当月に寄せない**こと（入金日が決まっていないのに今月の数字に混ぜない）。 */
    if (c.status === 'returned') return !!d && d >= fromStr && d <= toStr;

    /* 🔴 まだ返していない車は、もう終わった期間には出さない（締めた月の数字を後から動かさない） */
    if (toStr < todayStr) return false;

    var isCur = (todayStr >= fromStr && todayStr <= toStr);   /* いま見ている期間が「今」を含むか */
    if (!d) return isCur;                          /* 返車予定日が未定＝当月に寄せる */
    if (d >= fromStr && d <= toStr) return true;   /* 期間内＝そのまま */
    if (d > toStr) return false;                   /* 先の月＝そちらへずらす（ここには出さない） */
    return isCur;                                  /* 予定日が過ぎている＝当月に寄せる */
  }

  window.pitSalesCountDate = pitSalesCountDate;
  window.pitSalesTier      = pitSalesTier;
  window.pitSalesInRange   = pitSalesInRange;
  window.pitSalesHoldOf    = holdOf;
  window.pitCardHoldDays   = planHoldOf;   /* 🆕 v1.156.0 案内用（未選択なら null） */
})();
