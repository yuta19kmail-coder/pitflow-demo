/* ========================================
   search.js  -  マスター検索（PitFlow v0.65.0）
   ----------------------------------------
   ダッシュボード最上部の「検索」BOX。手元の小さな手がかり（名前・カナ・車・
   メーカー・ナンバー・予約番号・代車・日付・担当・メモ・電話）から全カードを
   横断検索し、ヒットしたカードをクリックで開く。
   ・スペース区切りで複数語＝すべて含む（AND）。例「6/13 アクア」
   ・日付は 2026-06-13 / 6/13 / 0613 / 20260613 などの表記でも当たる
   ・代車は「代車3」「L03」やナンバーでも、その代車を使っているカードに当たる
   ======================================== */
(function () {
  'use strict';

  // 表示先（ダッシュボード / マイダッシュボード で入力欄・結果欄が別idのため差替え可能に）。
  // 既定は従来のダッシュボード。各入力欄の onfocus で pitSearchBind() を呼んで切り替える。
  var ST = { wrap: 'pit-search-wrap', input: 'pit-search-input', results: 'pit-search-results' };
  window.pitSearchBind = function (wrap, input, results) {
    ST = { wrap: wrap || ST.wrap, input: input || ST.input, results: results || ST.results };
  };

  /* ================================================================
     🔤🔤 v2.39.0（2026-08-30）**旧字・異体字でも探せる**
     ----------------------------------------------------------------
     ◎なぜ（本番の名簿 6,322人を数えた結果）
       **436人（7%）が旧字・異体字を含む名前**だった。
       澤127／髙64／嶋45／﨑33／齋32／邊24／濱22／邉19／齊18／國17／冨13／眞9／舘5／藪4…
       ＝「**髙で探すと高が出ない／高で探すと髙が出ない**」が毎日起きる大きさ。
     ◎🔴 決めごと（ゆうたと決めた原則そのまま）
       **寄せるのは「探す時」だけ。**「この人だ」と決める引き当て（`_findPerson` など）では**寄せない。**
       ＝ 齋／齊／斎／斉 のように、**寄せると別姓が混ざる**字があるため。
         探しやすくするのは安全（人が見て選ぶ）／自動で同じ人にするのは危ない。
       ⚠ 実際、名簿で「**異体字だけが違う同じ読みの組**」は **5組しかなかった**（電話まで同じ組は0）。
         ＝ 自動でくっつける値打ちは小さく、危なさだけが残る。**探せれば足りる。**
     ◎やり方
       ① `normalize('NFKC')` … 互換漢字（﨑 德 塚 神 …）と全角英数・半角カナが**これだけで**そろう
       ② 下の表 … NFKC では動かない字（髙 澤 嶋 齋 …）を代表字へ寄せる
       ⚠ 表に足す時は**名簿にある字だけ**にすること（使わない字を増やすと、当たりすぎる方に転ぶ）
     ================================================================ */
  const 異体字 = {
    '髙':'高','﨑':'崎','濵':'浜','濱':'浜','邊':'辺','邉':'辺','栁':'柳','桒':'桑',
    '齋':'斎','齊':'斉','嶌':'島','嶋':'島','冨':'富','藪':'薮','曾':'曽','舘':'館',
    '德':'徳','瀨':'瀬','眞':'真','惠':'恵','國':'国','澤':'沢','槗':'橋'
  };
  window.pitKanjiFold = function (s) {
    return String(s == null ? '' : s).replace(/[^\u0000-\u007F]/g, ch => 異体字[ch] || ch);
  };
  // 正規化：互換漢字・全角英数→半角・空白除去・カタカナ→ひらがな・旧字→新字・小文字化
  function norm(s) {
    let v = (s == null ? '' : String(s));
    try { v = v.normalize('NFKC'); } catch (e) {}          /* ① 互換漢字と全角英数 */
    return v
      .replace(/\s+/g, '')
      .replace(/[Ａ-Ｚａ-ｚ０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xFEE0))
      .replace(/[ァ-ヶ]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0x60))
      .replace(/[^\u0000-\u007F]/g, ch => 異体字[ch] || ch)   /* ② 旧字→新字（探す時だけ） */
      .toLowerCase();
  }
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  /* 🔴 v1.102.0（ゆうた報告「新規予約での検索の結果が薄い」）
     **探し方（文字のならし方・スペース区切りのAND）をここから配る。**
     ＝新規予約の「呼び出し」（customers.js の custSuggest）が**同じ規則**で探せるようにする。
     ⚠ 向こうに書き写さないこと。写した瞬間、片方だけ直して「マスター検索では出るのに呼び出しでは出ない」が戻る。
       ・pitSearchNorm(s)   … 空白を消す／全角英数→半角／カタカナ→ひらがな／小文字
       ・pitSearchWords(q)  … スペースで区切って語にする（全部含む＝AND） */
  window.pitSearchNorm = norm;
  window.pitSearchWords = function (qStr) {
    const raw = String(qStr || '').trim();
    return raw ? raw.split(/\s+/).map(norm).filter(Boolean) : [];
  };
  /* ================================================================
     🔴🔴 v1.176.0（ゆうた指定 2026-08-22）**当たった所を塗る。**
     🗣「検索がヒットした時に**どこが当たってるのか**ハイライト表示。
     　　例えばナンバーで **920** で検索した時に **9/20** とかでヒットして
     　　？？？って迷って意外とはかどらない」
     ◎なにが困っていたか
       探し方は**全部つなげた1本の文字列**（`cardBlob`）に対する当たり判定なので、
       **どの欄で当たったのかが画面に一切出ていなかった**。
       ナンバーのつもりで打った数字が**日付**に当たっても、行を見ても分からない。
     🔴 **拾う範囲（何がヒットするか）は1文字も変えない。** 見えるようにするだけ。
     ================================================================ */

  /* ならし（norm）と同じことを1文字ずつやって、**元の文字の位置**を覚えておく。
     ⚠ norm は空白を消すので、そのままだと「ならした後の位置」から元の位置に戻れない。 */
  function normIndex(s) {
    var raw = (s == null ? '' : String(s));
    var out = '', idx = [];
    for (var i = 0; i < raw.length; i++) {
      var ch = raw[i];
      if (/\s/.test(ch)) continue;                      /* 空白は消す（norm と同じ） */
      ch = ch.replace(/[Ａ-Ｚａ-ｚ０-９]/g, function (c) { return String.fromCharCode(c.charCodeAt(0) - 0xFEE0); })
             .replace(/[ァ-ヶ]/g,        function (c) { return String.fromCharCode(c.charCodeAt(0) - 0x60); })
             .toLowerCase();
      for (var k = 0; k < ch.length; k++) { out += ch[k]; idx.push(i); }   /* 1文字が2文字になる字もある */
    }
    return { n: out, idx: idx, raw: raw };
  }

  /* 当たった所を <mark> で塗った HTML を返す（当たらなければ、ただの esc と同じ）。
     🔴 **塗るのは元の字**（ならした字ではない）＝画面の見た目は変わらない。 */
  function markHits(raw, words) {
    var text = (raw == null ? '' : String(raw));
    if (!text || !words || !words.length) return esc(text);
    var M = normIndex(text);
    if (!M.n) return esc(text);
    var hit = [];                                       /* 塗る場所（元の字の位置） */
    words.forEach(function (w) {
      if (!w) return;
      var from = 0, at;
      while ((at = M.n.indexOf(w, from)) >= 0) {
        var s0 = M.idx[at], e0 = M.idx[at + w.length - 1];
        if (s0 != null && e0 != null) hit.push([s0, e0 + 1]);
        from = at + 1;                                  /* 重なりも拾う */
      }
    });
    if (!hit.length) return esc(text);
    hit.sort(function (a, b) { return a[0] - b[0]; });
    var merged = [];                                    /* 重なった塗りはつなげる */
    hit.forEach(function (r) {
      var last = merged[merged.length - 1];
      if (last && r[0] <= last[1]) { if (r[1] > last[1]) last[1] = r[1]; }
      else merged.push([r[0], r[1]]);
    });
    var html = '', pos = 0;
    merged.forEach(function (r) {
      html += esc(text.slice(pos, r[0])) + '<mark class="psr-hit">' + esc(text.slice(r[0], r[1])) + '</mark>';
      pos = r[1];
    });
    return html + esc(text.slice(pos));
  }

  /* どの欄で当たったか（欄の名前を、出てきた順で重複なしに）。
     🔴 欄の表は `cardFields` / `custFields` の1本。**画面で組み立てない。**
     🔴🔴 日付は「9/20」「0920」のような**別の書き方でも当たる**作りなので、
        当たった書き方（`as`）も一緒に返す。＝ **920 でナンバーのつもりが 9/20 に当たった**時に、
        画面の「2026-09-20」を見ても分からない、というのが今回の困りごとそのもの。 */
  function whereHits(fields, words) {
    var out = [], seen = {};
    (fields || []).forEach(function (f) {
      var n = norm(f.text);
      if (!n) return;
      var any = (words || []).some(function (w) { return w && n.indexOf(w) >= 0; });
      if (!any) return;
      if (seen[f.label]) return;
      seen[f.label] = 1; out.push({ label: f.label, as: f.as || '' });
    });
    return out;
  }

  /* 🔴 v1.176.0 新規予約の「呼び出し」からも同じものを使う（あちらに書き写さない） */
  window.pitSearchMark  = markHits;
  window.pitSearchWhere = whereHits;

  // N日前の日付文字列（YYYY-MM-DD）＝返車済みの「直近1か月」判定に使う
  function _daysAgoStr(n) {
    const d = new Date(); d.setDate(d.getDate() - n);
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }

  // ステータスの日本語ラベル
  function statusLabel(c) {
    if (c.status === 'reserved') return '予約';
    /* 🔴 v1.101.0 キャンセル＝人が決めたもの／未入庫＝来なかっただけ。**別物なので言い分ける。**
       🔴 v1.164.0 言葉は pit-share.js の `pitCancelText` から借りる（ここで綴らない）。
          ⚠ 直す前はここだけ「キャンセル」で、カード詳細の札は「予約キャンセル」だった。 */
    if (c.status === 'cancelled') return window.pitCancelText ? pitCancelText(c) : (c.cancelled ? '予約キャンセル' : '未入庫');
    /* 🔴 v1.99.0 売上なしでアーカイブした車は、探した人が取り違えないよう「売上なし」と言い切る */
    if (window.pitCardNoSale && pitCardNoSale(c)) return '売上なし';
    if (c.status === 'returned') return '返車済み';
    const board = (state.boards || []).find(b => b.id === c.boardId) || (state.boards || [])[0];
    const col = board && (board.cols || []).find(x => x.id === c.status);
    return col ? col.name : (c.status || '');
  }
  function teamLabel(c) { return c.boardId === 'import' ? '輸入車' : (c.boardId === 'default' ? '国産車' : ''); }

  // 日付を複数表記で検索対象に（2026-06-13 / 6/13 / 06/13 / 0613 / 20260613）
  function dateForms(d) {
    if (!d) return [];
    const p = String(d).split('-');
    if (p.length !== 3) return [d];
    const y = p[0], m = p[1], day = p[2];
    return [d, m + '/' + day, (+m) + '/' + (+day), m + day, y + m + day];
  }

  /* 🔴🔴 v1.176.0 **カード1枚の「検索の材料」を、欄の名前つきの表にした。**
     ＝ 探すのに使う文字と、「どの欄で当たったか」を出す元が**同じ1本**になる。
     ⚠ 中身（拾う範囲）は**1文字も変えていない**。名前を付けて並べ替えただけ。
     　 ここに欄を足す＝検索に当たる範囲が広がる、ということ。 */
  function cardFields(c) {
    const F = [];
    const add = (label, v) => { if (v) F.push({ label: label, text: String(v) }); };
    add('予約番号', c.resNo); add('お名前', c.customer); add('カナ', c.kana);
    add('車種', c.car); add('メーカー', c.maker); add('ナンバー', c.plate);
    add('TEL', c.tel); add('作業内容', c.menu);
    add('担当', c.frontStaff); add('担当', c.staff);
    add('メモ', c.memo); add('事務', c.office);
    add('状態', statusLabel(c)); add('国産／輸入', teamLabel(c));
    (c.contacts || []).forEach(ct => { add('TEL', ct.tel); add('TEL', ct.label); });
    /* 🔴🔴 v1.176.0 日付は**別の書き方でも当たる**（2026-09-20 / 09/20 / 9/20 / 0920 / 20260920）。
       ＝ 「920」でナンバーのつもりが**日付に当たる**のは、この 0920 のせい。
       🔴 どの書き方で当たっても、行には**人が読む形（9/20）**を添える。
          ⚠ 当たった生の形（0920）をそのまま出しても、読んだ人はやっぱり分からない。 */
    const nice = (d) => { const q = String(d || '').split('-'); return q.length === 3 ? ((+q[1]) + '/' + (+q[2])) : ''; };
    dateForms(c.reserveDate).forEach(x => { if (x) F.push({ label:'入庫日', text:String(x), as: nice(c.reserveDate) }); });
    dateForms(c.returnDate).forEach(x => { if (x) F.push({ label:'返車日', text:String(x), as: nice(c.returnDate) }); });
    if (c.loanerId) {
      const l = (state.loaners || []).find(x => x.id === c.loanerId);
      if (l) { add('代車', l.name); add('代車', l.model); add('代車', l.plate); }
      add('代車', c.loanerId); add('代車', '代車');
    }
    return F;
  }
  // カード1枚の検索用テキスト（全部つなげて正規化）
  function cardBlob(c) {
    return norm(cardFields(c).map(f => f.text).join(' '));
  }
  /* 🔎 v2.17.0 実績ビューの検索も**この表を借りる**（あちらに探し方を書き写さない）。
     🔴 ここに欄を足す＝上の検索も実績の検索も一緒に広がる、ということ。 */
  window.pitCardFields = cardFields;
  window.pitCardBlob   = cardBlob;

  // 顧客台帳（人＋車両）の検索用テキスト
  function custPrimaryTel(cust) {
    const cs = (cust && cust.contacts) || [];
    const p = cs.find(x => x.primary) || cs[0];
    return p ? (p.tel || '') : '';
  }
  /* 🔴 v1.176.0 顧客も同じく「欄の名前つきの表」から（拾う範囲は変えていない） */
  function custFields(cust) {
    const F = [];
    const add = (label, v) => { if (v) F.push({ label: label, text: String(v) }); };
    add('お名前', cust.name); add('カナ', cust.kana);
    (cust.contacts || []).forEach(ct => { add('TEL', ct.tel); add('TEL', ct.label); });
    /* 🔴 v1.49.0 アーカイブした車のナンバー・車種では、その顧客を検索に出さない。
       ⚠ ここを外すと「片付けたはずの車のナンバー」で顧客が引っかかる。 */
    (cust.vehicles || [])
      .filter(v => (window.PitArchive ? !PitArchive.vehArchived(cust, v) : true))
      .forEach(v => { add('ナンバー', v.plate); add('メーカー', v.maker); add('車種', v.car); });
    return F;
  }
  function custBlob(cust) {
    return norm(custFields(cust).map(f => f.text).join(' '));
  }
  function searchCustomers(words) {
    /* 🔴 v1.49.0 アーカイブした顧客は検索に出さない（archive-pit.js が判定）。
       ⚠ 消してはいない＝顧客画面の「アーカイブ済みを見る」から探せる。 */
    const list = (state.customers || []).filter(c => (window.PitArchive ? PitArchive.custVisible(c) : true));
    const hits = [];
    for (let i = 0; i < list.length; i++) {
      const blob = custBlob(list[i]);
      if (words.every(w => blob.indexOf(w) >= 0)) hits.push(list[i]);
    }
    hits.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    return hits;
  }

  // 検索本体：全語(AND)を含むカードを新しい順で返す
  function search(qStr) {
    // norm は空白を消すので、入力時のスペースで先に語分割してから各語を正規化
    const raw = String(qStr || '').trim();
    const words = raw ? raw.split(/\s+/).map(norm).filter(Boolean) : [];
    if (!words.length) return [];
    /* 🔴 v1.49.0 アーカイブした顧客・車両の入庫カードも検索に出さない（ゆうた指定）。
       ⚠ **実績ビュー・売上などの集計はここを通していない＝今までどおりの数字**。 */
    const cards = (state.cards || []).filter(c => (window.PitArchive ? PitArchive.cardVisible(c) : true));
    const hits = [];
    for (let i = 0; i < cards.length; i++) {
      const blob = cardBlob(cards[i]);
      if (words.every(w => blob.indexOf(w) >= 0)) hits.push(cards[i]);
    }
    hits.sort((a, b) => (b.reserveDate || '').localeCompare(a.reserveDate || ''));
    return hits;
  }

  function actBtn(label, onclick) {
    return '<button class="psr-act" onclick="event.stopPropagation();' + onclick + '">' + label + '</button>';
  }
  // 工程（車検等）・代車・当/待のバッジ（顧客情報の横に素直に並べる）
  function rowBadges(c) {
    let b = '';
    const wt = (state.workTypes || []).find(w => w.id === c.workType);
    if (wt) b += '<span class="psr-b" style="background:' + wt.color + '22;color:' + wt.color + ';border-color:' + wt.color + '66">' + esc(wt.label) + '</span>';
    if (c.loanerId || c.needLoaner) b += '<span class="psr-b psr-b-loaner">代車</span>';
    if (c.dropType === 'wait' || c.dropType === 'sameDay') {
      const dt = (state.dropTypes || []).find(d => d.id === c.dropType);
      b += '<span class="psr-b psr-b-drop">' + esc(dt ? dt.label : '') + '</span>';
    }
    return b ? ('<span class="psr-bs">' + b + '</span>') : '';
  }
  /* 🔴 v1.176.0 いま探している語（画面を描くたびに入れ替える）。
     ⚠ 行を作る関数の引数を増やすと `list.map(resultRow)` が全部壊れるので、
        **描く直前にここへ置いて、描き終わったら空にする**（画面の中だけの持ち物）。 */
  var WORDS = [];
  /* 当たった所の1行（どの欄で当たったか）。⚠ 1つも当たっていなければ何も出さない。 */
  function hitLine(fields) {
    const w = whereHits(fields, WORDS);
    if (!w.length) return '';
    return '<div class="psr-where"><i data-ic=search data-ics=14></i>'
         + w.map(function (x) {
             return '<span>' + esc(x.label) + (x.as ? '<em>' + esc(x.as) + '</em>' : '') + '</span>';
           }).join('')
         + 'に一致</div>';
  }
  function resultRow(c) {
    const id = esc(c.id);
    const no = c.resNo ? '<span class="psr-no">' + markHits(c.resNo, WORDS) + '</span>' : '';
    const st = statusLabel(c);
    const team = c.boardId === 'import' ? '#ec4899' : '#1db97a';
    // ステータスバッジは左（予約番号の下）
    const stBadge = '<span class="psr-st" style="border-color:' + team + ';color:' + team + '">' + esc(st) + '</span>';
    // 日時：返車済み＝完了日(＋金額)、それ以外＝予約日(＋時刻・期間)
    let dstr;
    if (window.pitCardNoSale && pitCardNoSale(c)) {
      /* 🔴 v1.99.0 売上なし＝金額を出さない。来た日（入庫日）と「売上なし」だけ */
      dstr = (c.reserveDate || c.returnDate || '') + ' 来店　売上なし';
    } else if (c.status === 'returned') {
      const amt = (c.amountFinal != null && c.amountFinal !== '') ? Number(c.amountFinal) : null;
      dstr = (c.returnDate || '') + ' 完了' + ((amt != null && isFinite(amt)) ? ('　¥' + amt.toLocaleString('ja-JP')) : '');
    } else {
      dstr = (c.reserveDate || '') + (c.reserveTime ? (' ' + c.reserveTime) : '') + (c.returnDate && c.returnDate !== c.reserveDate ? ('〜' + c.returnDate) : '');
    }
    const tel = c.tel || ((c.contacts || []).find(x => x.primary) || {}).tel || '';
    // 右に操作ボタン：入庫前(予約)＝予約詳細/予約カレンダー/顧客情報/新規予約
    const rd = esc(c.reserveDate || '');
    let acts;
    if (c.status === 'reserved') {
      acts = actBtn('予約詳細', "pitOpenCardDetail('" + id + "')")
           + actBtn('予約カレンダー', "pitGotoReserveDate('" + rd + "')")
           + actBtn('顧客情報', "custOpenForCard('" + id + "')")
           + actBtn('新規予約', "custNewReserveForCardId('" + id + "')");
    } else if (c.status === 'returned') {
      acts = actBtn('予約詳細', "pitOpenCardDetail('" + id + "')")
           /* 🔎 v2.17.0 カードidも渡す＝飛んだ先でその日とそのカードが光る（来店履歴からと同じ形） */
           + actBtn('実績カレンダー', "pitGotoResultMonth('" + esc(c.returnDate || c.reserveDate || '') + "','" + id + "')")
           + actBtn('顧客情報', "custOpenForCard('" + id + "')");
    } else {
      acts = actBtn('予約詳細', "pitOpenCardDetail('" + id + "')")
           + actBtn('顧客情報', "custOpenForCard('" + id + "')");
    }
    return '<div class="psr-row">'
      + '<div class="psr-lead">' + no + stBadge + '</div>'
      + '<div class="psr-main">'
      + '<div class="psr-l1"><b class="psr-name">' + markHits((window.pitCustName?pitCustName(c):c.customer) || '（未入力）', WORDS) + ' 様</b>'
      + (c.car ? '<span class="psr-car">' + markHits(c.car, WORDS) + '</span>' : '')
      + (c.plate ? '<span class="psr-plate">' + markHits(c.plate, WORDS) + '</span>' : '')
      + rowBadges(c)
      + '</div>'
      + '<div class="psr-l2">' + (tel ? ('<i data-ic=phone data-ics=16></i> ' + markHits(tel, WORDS)) : '') + (dstr ? ((tel ? '　・　' : '') + '<i data-ic=calendar data-ics=16></i> ' + markHits(dstr, WORDS)) : '') + '</div>'
      + hitLine(cardFields(c))
      + '</div>'
      + '<div class="psr-acts">' + acts + '</div>'
      + '</div>';
  }

  /* 🗓 v2.9.4 最終入庫は **customers.js の `pitCustLastVisit` 1本**を借りる。
     ⚠ ここで `updatedAt`（レコードを触った時刻）を「最終入庫」として出さないこと。
        それをやっていたので「入庫していないのに最終入庫 8/20」が出ていた（ゆうた 2026-08-25）。 */
  function custLastVisit(cust) {
    if (!window.pitCustLastVisit) return '';
    var d = String(window.pitCustLastVisit(cust) || '').trim();
    return d ? d.replace(/-/g, '/') : '';
  }
  // 顧客（人）1件の結果行：上＝名前・車種・ナンバー／下＝電話・最終入庫。右に操作ボタン
  function custRow(cust) {
    const tel = custPrimaryTel(cust);
    const vs = cust.vehicles || [];
    const v0 = vs[0] || {};
    const car = v0.car ? '<span class="psr-car">' + markHits(v0.car, WORDS) + '</span>' : '';
    const plate = v0.plate ? '<span class="psr-plate">' + markHits(v0.plate, WORDS) + '</span>' : '';
    const more = vs.length > 1 ? '<span class="psr-more">ほか' + (vs.length - 1) + '台</span>' : '';
    const last = custLastVisit(cust);
    return '<div class="psr-row">'
      + '<div class="psr-lead"><span class="psr-cust-tag"><i data-ic=user data-ics=16></i></span></div>'
      + '<div class="psr-main">'
      + '<div class="psr-l1"><b class="psr-name">' + markHits(cust.name || '（無名）', WORDS) + ' 様</b>' + car + plate + more + '</div>'
      + '<div class="psr-l2">' + (tel ? ('<i data-ic=phone data-ics=16></i> ' + markHits(tel, WORDS)) : '') + (last ? ((tel ? '　・　' : '') + '最終入庫 ' + esc(last)) : '') + '</div>'
      + hitLine(custFields(cust))
      + '</div>'
      + '<div class="psr-acts">'
      + actBtn('顧客情報', "pitSearchOpenCust('" + esc(cust.id) + "')")
      + actBtn('新規予約', "pitSearchClose();custNewReserveFor('" + esc(cust.id) + "','" + esc(v0.id || '') + "')")
      + '</div>'
      + '</div>';
  }

  /* ============================================================
     🔴🔴 v1.177.0（ゆうた報告「なんか検索ボックスの挙動が おそい・・・」）
     ------------------------------------------------------------
     ◎何が遅かったか（6,200人・1,200カードで実測、1文字「9」＝6,230件出る時）
       ① 行を組み立てる（レイアウト）… **11.5 秒**  ← ほぼ全部これ
       ② アイコンを流し込む         … 2.5 秒
       ③ 探して文字を作る           … 0.6 秒
       ＝ 合計 **約 14.7 秒**。しかも1文字打つたびに、これを最初からやり直していた。
     ◎直し方（**出す数は1件も減らしていない**）
       ① CSS の `content-visibility`（css/search.css）… 画面の外にある行は開いた時に組み立てる
       ② 打っている間は描き直さない（下の `pitTypeSoon`）… 「920」なら3回→1回
       ③ 顧客の残りは次の周期から足す（下の `restSoon`）… 最初の1画面がすぐ出る
       ＝ 同じ条件で **約 0.5 秒**。
     ⚠ **探し方（何が当たるか）も、出す件数も、1文字も変えていない。** 出し方だけ。
     ⚠ `pitSearchInput(q)` は今までどおり「呼んだらその場で描く」まま
        （試験・フォーカス復帰・`pitSearchReopen` がこれを使う）。待つのは `pitSearchSoon` の側。
     ============================================================ */
  var FIRST = 100;                        /* 顧客の最初に組み立てる件数（残りは restSoon が足す） */
  var _rest = null;
  function restSoon(list, from, words) {
    if (_rest) { clearTimeout(_rest); _rest = null; }
    var host = document.getElementById('psr-cust-rows');
    if (!host) return;
    var i = from;
    var step = function () {
      _rest = null;
      /* 描き直された時は、その箱ごと入れ替わっている＝この続きはもう要らない */
      if (document.getElementById('psr-cust-rows') !== host) return;
      var end = Math.min(i + 300, list.length);
      WORDS = words;
      var frag = '';
      for (var k = i; k < end; k++) frag += custRow(list[k]);
      WORDS = [];
      host.insertAdjacentHTML('beforeend', frag);
      i = end;
      if (i < list.length) _rest = setTimeout(step, 0);
    };
    _rest = setTimeout(step, 0);
  }

  /* 打ち終わるまで待って1回だけ描く。key ごとに別々に数える（マスター検索／呼び出し）。
     ⚠ 変換中（IME）は長めに待つ＝「やまだ」の途中で数千件を組み立てない。 */
  var _soon = {};
  window.pitTypeSoon = function (key, ev, fn) {
    if (_soon[key]) clearTimeout(_soon[key]);
    var ms = (ev && ev.isComposing) ? 400 : 140;
    _soon[key] = setTimeout(function () { _soon[key] = null; fn(); }, ms);
  };
  /* 検索欄の oninput はこちらを呼ぶ（消した時だけは待たずにすぐ閉じる） */
  window.pitSearchSoon = function (q, ev) {
    var v = String(q == null ? '' : q);
    if (!v.trim()) {
      if (_soon.search) { clearTimeout(_soon.search); _soon.search = null; }
      window.pitSearchInput(v);
      return;
    }
    window.pitTypeSoon('search', ev, function () { window.pitSearchInput(v); });
  };

  // 入力ハンドラ
  window.pitSearchInput = function (q) {
    const box = document.getElementById(ST.results);
    if (!box) return;
    if (_rest) { clearTimeout(_rest); _rest = null; }   /* 前の続きは捨てる */
    const raw = String(q || '').trim();
    if (!raw) { box.classList.remove('open'); box.innerHTML = ''; return; }
    const words = raw.split(/\s+/).map(norm).filter(Boolean);
    WORDS = words;                         /* 🔴 v1.176.0 この描き直しのあいだだけ、当たった所を塗る */
    const cardHits = search(q);
    const custHits = searchCustomers(words);
    if (!cardHits.length && !custHits.length) {
      box.innerHTML = '<div class="psr-empty">「' + esc(raw) + '」に当てはまるものはありません</div>';
      box.classList.add('open');
      return;
    }
    // 返車済みは溜まる一方なので「直近1か月」だけ🗂カードに、それより前は📦過去入庫へ分離
    const cut = _daysAgoStr(31);
    const recent = [], past = [];
    cardHits.forEach(function (c) {
      const isPast = (c.status === 'returned') && ((c.returnDate || c.reserveDate || '') < cut);
      (isPast ? past : recent).push(c);
    });
    const MAX = 30;
    const sec = function (icon, name, list, note) {
      if (!list.length) return '';
      return '<div class="psr-head">' + icon + ' ' + name + ' ' + list.length + '件'
        + (list.length > MAX ? '（上位' + MAX + '件）' : '') + (note ? '　' + note : '') + '</div>'
        + list.slice(0, MAX).map(resultRow).join('');
    };
    let html = '';
    html += sec('<i data-ic=folder data-ics=16></i>', 'カード', recent, '');                       // 予約・作業中・直近1か月の返車済み
    /* 🔴 v1.102.1（ゆうた指定）**顧客は上限なし＝全件出す。**
       ⚠ カード（入庫予約・過去入庫）は今までどおり上位30件。
          あちらは「探して開く」もので、多すぎると逆に見つからない。顧客は台帳なので全部見せる。
       ⚠ 数が多い時は、何件出しているかを出したうえで「もう1語足すと絞れる」と添える（黙って切らない）。 */
    if (custHits.length) {
      html += '<div class="psr-head"><i data-ic=user data-ics=16></i> 顧客 ' + custHits.length + '件'
            + (custHits.length > MAX ? '<span style="color:var(--text3)">　全部出しています。スペースで区切ってもう1語足すと絞れます</span>' : '')
            + '</div>';
      /* 🔴 v1.177.0 顧客は全件出す（v1.102.1 のまま）が、**組み立ては先頭 FIRST 件だけ先に**。
         残りは下の `restSoon()` が次の周期から足していく（切っていない・数は上の見出しが本当の数）。 */
      html += '<div id="psr-cust-rows">' + custHits.slice(0, FIRST).map(custRow).join('') + '</div>';
    }
    html += sec('<i data-ic=box data-ics=16></i>', '過去入庫', past, '<span style="color:var(--text3)">（1か月より前の返車済み）</span>');
    box.innerHTML = html;
    WORDS = [];                            /* 描き終わったら空に戻す（次の描き直しで入れ直す） */
    box.classList.add('open');
    if (custHits.length > FIRST) restSoon(custHits, FIRST, words);
  };

  // 顧客の結果クリック＝顧客詳細を直接開く（戻れるようにワードは残す）
  window.pitSearchOpenCust = function (custId) {
    window._pitReturnToSearch = true;
    if (window.pitSearchHide) pitSearchHide();
    if (window.custOpen) custOpen(custId);
  };

  // 結果クリック＝カードを開く
  window.pitSearchOpen = function (id) {
    pitSearchClose();
    if (window.openDetail) openDetail(id);
  };

  window.pitSearchClose = function () {
    const box = document.getElementById(ST.results);
    const inp = document.getElementById(ST.input);
    if (box) { box.classList.remove('open'); box.innerHTML = ''; }
    if (inp) inp.value = '';
  };
  // パネルだけ隠す（入力ワードは残す＝あとで戻れる）
  window.pitSearchHide = function () {
    const box = document.getElementById(ST.results);
    if (box) box.classList.remove('open');
  };
  // 直前の検索ワードで結果を出し直す（顧客情報を見て戻る用）
  // ※クリックで閉じた直後の「枠外クリックで閉じる」処理に巻き込まれないよう、次の周期で復元
  window.pitSearchReopen = function () {
    setTimeout(function () {
      const inp = document.getElementById(ST.input);
      if (inp && inp.value.trim()) window.pitSearchInput(inp.value);
    }, 0);
  };

  // 外側クリックで結果を閉じる（入力は残す）
  document.addEventListener('click', function (e) {
    const wrap = document.getElementById(ST.wrap);
    const box = document.getElementById(ST.results);
    if (!wrap || !box) return;
    if (!wrap.contains(e.target)) box.classList.remove('open');
  });
  // 入力にフォーカスが戻ったら、語があれば再表示（どちらの検索欄でも）
  document.addEventListener('focusin', function (e) {
    if (e.target && (e.target.id === 'pit-search-input' || e.target.id === 'mydash-search-input') && e.target.value.trim()) {
      window.pitSearchInput(e.target.value);
    }
  });

  console.log('[search] ready');
})();
